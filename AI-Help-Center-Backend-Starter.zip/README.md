# AI Help Center — backend starter

This is a **starter backend**, not a deployed service and not a fully connected AI assistant yet. It is intended for a first controlled test through a **Facebook Page Messenger** webhook.

## Included
- Health endpoint: `GET /`
- Meta webhook verification: `GET /webhook`
- Incoming Page Messenger events: `POST /webhook`
- Basic keyword category detection for the planned Help Center categories
- Safety-first test reply in Hindi
- Meta webhook signature verification when `META_APP_SECRET` is configured
- No secrets committed; `.env` is ignored by Git

## Important limitations
- This starter is for **Page Messenger**, not automatic reading/commenting on Facebook Group posts. Group API access and permissions are separate and may not be available for this workflow.
- It does **not** call an AI model yet. `createHelpReply()` is the clearly marked place to add one after choosing a provider and adding a server-side API key.
- It is not deployed. Meta requires a publicly reachable HTTPS URL for webhook configuration.
- Production deployment should use a managed host, environment secrets, request logging with personal data minimized, rate limits, a queue/retry strategy, and tested privacy/consent behavior.

## Local test
1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env`.
3. Set a long random `VERIFY_TOKEN`. Keep `.env` private.
4. Run `npm install`, then `npm start`.
5. Open `http://localhost:3000/`; you should see `status: running`.

Meta cannot reach localhost directly. Deploy to an HTTPS host before configuring the webhook in Meta Developer Dashboard.

## Meta setup after deployment
- Use the deployed base URL plus `/webhook` as Callback URL.
- Enter the exact same `VERIFY_TOKEN` in Meta and the server environment.
- Configure the Page subscription and required Messenger permissions in Meta.
- Set `PAGE_ACCESS_TOKEN` and `META_APP_SECRET` as server environment secrets, not in browser/mobile code or public posts.
- Test with your own Page and test account before inviting users.

## Safety notes
Never ask users to send passwords, OTPs, UPI PINs, full card numbers, or secret credentials. For government services, payments, vacancies, legal or other time-sensitive claims, verify against official sources and escalate when uncertain.
