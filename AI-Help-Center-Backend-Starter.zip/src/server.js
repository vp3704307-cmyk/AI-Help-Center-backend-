require("dotenv").config();
const express = require("express");
const crypto = require("crypto");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const VERIFY_TOKEN = process.env.VERIFY_TOKEN || "";

app.use(express.json({
  verify: (req, res, buf) => { req.rawBody = buf; }
}));

app.get("/", (_req, res) => {
  res.status(200).json({
    service: "AI Help Center backend",
    status: "running",
    note: "Messenger webhook starter. Configure Meta webhook only after deploying to public HTTPS."
  });
});

// Meta webhook verification handshake
app.get("/webhook", (req, res) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];

  if (mode === "subscribe" && token && VERIFY_TOKEN && token === VERIFY_TOKEN) {
    return res.status(200).send(String(challenge || ""));
  }
  return res.sendStatus(403);
});

// Verify that incoming webhook events were signed by Meta, when app secret is configured.
function verifyMetaSignature(req) {
  const secret = process.env.META_APP_SECRET;
  if (!secret) return process.env.NODE_ENV !== "production"; // local-only convenience
  const signature = req.get("x-hub-signature-256") || "";
  if (!signature.startsWith("sha256=") || !req.rawBody) return false;
  const expected = "sha256=" + crypto.createHmac("sha256", secret).update(req.rawBody).digest("hex");
  const a = Buffer.from(signature);
  const b = Buffer.from(expected);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

app.post("/webhook", async (req, res) => {
  if (!verifyMetaSignature(req)) return res.sendStatus(401);

  // Acknowledge quickly; handle events asynchronously in a production queue.
  res.sendStatus(200);

  try {
    const body = req.body;
    if (body.object !== "page") return;

    for (const entry of body.entry || []) {
      for (const event of entry.messaging || []) {
        if (event.message && !event.message.is_echo && event.message.text) {
          const senderId = event.sender && event.sender.id;
          const text = event.message.text.trim();
          if (!senderId || !text) continue;

          const result = await createHelpReply(text);
          await sendMessengerText(senderId, result.reply);
          console.log(JSON.stringify({
            type: "message_handled",
            category: result.category,
            confidence: result.confidence,
            escalated: result.escalated
          }));
        }
      }
    }
  } catch (err) {
    console.error("Webhook processing error:", err.message);
  }
});

function detectCategory(message) {
  const t = message.toLowerCase();
  const rules = [
    ["UPI/Payment", ["upi", "payment", "पैसा", "पेमेंट", "ट्रांजैक्शन", "transaction", "bank"]],
    ["Government Services", ["आधार", "aadhaar", "pan card", "पैन", "सरकारी योजना", "sarkari yojana"]],
    ["Government Jobs", ["सरकारी नौकरी", "sarkari job", "vacancy", "भर्ती", "rojgar"]],
    ["Private Jobs/CV", ["resume", "cv", "नौकरी", "job", "interview"]],
    ["Documents/Forms", ["फॉर्म", "form", "document", "दस्तावेज", "certificate"]],
    ["Agriculture", ["खेती", "किसान", "फसल", "agriculture", "बीज", "खाद"]],
    ["Mobile & Apps", ["मोबाइल", "mobile", "app", "फोन", "phone", "login"]],
    ["Education", ["पढ़ाई", "education", "school", "college", "exam", "परीक्षा"]],
    ["Delivery", ["delivery", "डिलीवरी", "parcel", "राइडर", "rider"]],
    ["Business", ["business", "व्यापार", "दुकान", "shop"]],
    ["AI Help", ["ai", "एआई", "chatgpt", "gemini"]],
    ["Creator Help", ["video", "creator", "reel", "youtube", "फेसबुक वीडियो"]],
    ["Online Process", ["online", "ऑनलाइन", "website", "वेबसाइट", "registration", "रजिस्ट्रेशन"]]
  ];
  for (const [category, words] of rules) {
    if (words.some(word => t.includes(word))) return category;
  }
  return "Other Problem";
}

async function createHelpReply(message) {
  const category = detectCategory(message);
  // Safe initial test mode: no invented official facts and no external AI call yet.
  // Connect a model provider only after adding credentials and review safeguards.
  const reply = `नमस्ते! आपकी समस्या "${category}" श्रेणी में रखी गई है।\\n\\nAI Help Center अभी टेस्ट मोड में है, इसलिए यह जवाब अपने-आप अंतिम समाधान नहीं देता। कृपया समस्या के साथ संबंधित वेबसाइट/ऐप का नाम और स्क्रीन पर दिख रहा error लिखें। अपना OTP, पासवर्ड, UPI PIN या पूरा बैंक विवरण साझा न करें।\\n\\nयदि मामला पैसे, सरकारी पात्रता या नौकरी की अंतिम तारीख से जुड़ा है, तो आधिकारिक स्रोत से पुष्टि आवश्यक है।`;
  return { category, confidence: "low", escalated: true, reply };
}

async function sendMessengerText(recipientId, messageText) {
  const pageToken = process.env.PAGE_ACCESS_TOKEN;
  if (!pageToken) {
    console.warn("PAGE_ACCESS_TOKEN missing; reply not sent. Set it in environment variables.");
    return;
  }

  const url = "https://graph.facebook.com/v23.0/me/messages?access_token=" +
    encodeURIComponent(pageToken);
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      recipient: { id: recipientId },
      messaging_type: "RESPONSE",
      message: { text: messageText }
    })
  });

  if (!response.ok) {
    const body = await response.text();
    console.error("Messenger send failed:", response.status, body);
  }
}

app.listen(PORT, () => {
  console.log(`AI Help Center backend listening on port ${PORT}`);
});
